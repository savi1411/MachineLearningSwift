import CreateML
import Foundation

// Specify Data
let trainingDir = URL(fileURLWithPath: "/Users/savi1411/Desktop/TrainingPets")
let testingDir = URL(fileURLWithPath: "/Users/savi1411/Desktop/TestingPets")

// Create Model
let model = try MLImageClassifier(trainingData: .labeledDirectories(at: trainingDir))

//Evaluate Model
let evaluation = model.evaluation(on: .labeledDirectories(at: testingDir))

// Save Model
try model.write(to: URL(fileURLWithPath: "/Users/savi1411/Desktop/Models"))

